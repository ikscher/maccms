﻿
var pwidth=640;     //播放器宽度
var pheight=510;    //播放器高度
var adsloadtime=5000; //播放前广告时间 1000表示1秒
var maccmsplay=3;  //播放器版本2普通版本,3美化版本
var popenW=704;    //弹窗窗口宽度
var popenH=566;    //弹窗窗口高度
var autoFull=0;    //是否自动全屏,0否,1是
var showlist=0;    //美化版播放器是否显示列表
var loadads="http://union.maccms.com/html/loading7.html";   //预加载广告地址
var colors="000000,F6F6F6,F6F6F6,333333,666666,FFFFF,FF0000,2c2c2c,ffffff,a3a3a3,2c2c2c,adadad,adadad,48486c,fcfcfc";   //背景色，文字颜色，链接颜色，分组标题背景色，分组标题颜色，当前分组标题颜色，当前集数颜色，集数列表滚动条凸出部分的颜色，滚动条上下按钮上三角箭头的颜色，滚动条的背景颜色，滚动条空白部分的颜色，滚动条立体滚动条阴影的颜色 ，滚动条亮边的颜色，滚动条强阴影的颜色，滚动条的基本颜色

